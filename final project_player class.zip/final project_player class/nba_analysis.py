import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.metrics import pairwise_distances, euclidean_distances
from sklearn.metrics import silhouette_score
from yellowbrick.cluster import KElbowVisualizer
from collections import defaultdict

###################################
######## Data Input ###############
###################################

# read in data
players_12_13 = pd.read_csv('player_data_2012-13.csv')
players_23_24 = pd.read_csv('player_data_2023-24.csv')

# remove duplicates and unnecessary columns
initial_columns_to_drop = ['Age_per_gm', 'Age_shoot', 'Awards_per_gm', 'GS_per_gm', 'G_per_gm',
                           'G_shoot', 'MP_adv', 'MP_shoot', 'PER_adv', 'Player First_shoot',
                           'Player Last_shoot', 'Player_per_gm', 'Player_shoot', 'Pos_adv',
                           'Pos_shoot', 'Team_per_gm', 'Team_shoot', 'player_id', 'player_name',
                           'season', 'Player First _shoot']
players_23_24_edited = players_23_24.drop(
    columns=[col for col in initial_columns_to_drop if col in players_23_24.columns])
players_12_13_edited = players_12_13.drop(
    columns=[col for col in initial_columns_to_drop if col in players_12_13.columns])

# add dummies
players_23_24_edited['ind_usa'] = (players_23_24_edited['country'] == 'USA').astype(int)
players_12_13_edited['ind_usa'] = (players_12_13_edited['country'] == 'USA').astype(int)

# apply filters
players_23_24_edited = players_23_24_edited[players_23_24_edited['G_adv'] > 40]
players_12_13_edited = players_12_13_edited[players_12_13_edited['G_adv'] > 40]

# remove more columns for model processing
model_columns_to_drop = ['country', 'Tm_adv', 'Pos_per_gm', 'Player_adv', 'season']
players_23_24_model = players_23_24_edited.drop(
    columns=[col for col in model_columns_to_drop if col in players_23_24_edited.columns])
players_12_13_model = players_12_13_edited.drop(
    columns=[col for col in model_columns_to_drop if col in players_12_13_edited.columns])

# clean data (remove NaN)
columns_to_impute = ['3P%_per_gm', '3P_shoot', '3P+_shoot', '3PAr+_shoot']
players_23_24_model[columns_to_impute] = players_23_24_model[columns_to_impute].fillna(0.00)
players_12_13_model[columns_to_impute] = players_12_13_model[columns_to_impute].fillna(0.00)
print(players_23_24_model.columns)
###################################
######## Feature Selection ########
###################################

# standardize data
scaler = StandardScaler()
scaler_players_23_24 = scaler.fit_transform(players_23_24_model)
scaler_players_12_13 = scaler.fit_transform(players_12_13_model)


def principal_component_selection(X, n_clusters=None, n_components=10):
    # feature selection kmeans based on PCA, structure from
    # https://datascience.stackexchange.com/questions/67040/how-to-do-feature-selection-for-clustering-and-implement-it
    # -in-python
    pca = PCA(n_components=n_components).fit(X)
    A_q = pca.components_.T

    if n_clusters == None:
        kmeans = KMeans(n_init='auto').fit(A_q)
    else:
        kmeans = KMeans(n_clusters=n_clusters, n_init='auto').fit(A_q)
    clusters = kmeans.predict(A_q)
    cluster_centers = kmeans.cluster_centers_

    dists = defaultdict(list)
    for i, c in enumerate(clusters):
        dist = euclidean_distances([A_q[i, :]], [cluster_centers[c, :]])[0][0]
        dists[c].append((i, dist))

    # gives inds of selected features based on variance
    pfa_indices = [sorted(f, key=lambda x: x[1])[0][0] for f in dists.values()]

    return pfa_indices


# pfa feature selected model input
# 12-13
pfa_inds_12_13 = principal_component_selection(scaler_players_12_13)
pfa_players_12_13 = players_12_13_model.iloc[:, pfa_inds_12_13]
# 23-24
pfa_inds_23_24 = principal_component_selection(scaler_players_23_24)
pfa_players_23_24 = players_23_24_model.iloc[:, pfa_inds_23_24]
print(pfa_players_23_24.columns)

# hand selected model input; advanced shooting data only
hand_selected_vars = ['Age_adv', 'G_adv', 'ORB%_adv', 'DRB%_adv', 'TRB%_adv', 'AST%_adv', 'STL%_adv', 'BLK%_adv',
                      'TOV%_adv',
                      'USG%_adv', 'OWS_adv', 'DWS_adv', 'WS_adv', 'WS/48_adv', 'OBPM_adv',
                      'DBPM_adv', 'BPM_adv', 'VORP_adv', 'MP_per_gm', 'ORB_per_gm', 'DRB_per_gm', 'TRB_per_gm',
                      'AST_per_gm', 'STL_per_gm', 'BLK_per_gm', 'TOV_per_gm', 'PF_per_gm',
                      'PTS_per_gm', 'FG_shoot', 'FTr_shoot', '3PAr_shoot', 'FG+_shoot',
                      '2P+_shoot', 'eFG+_shoot', 'FT+_shoot', 'TS+_shoot',
                      'FTr+_shoot', '3PAr+_shoot', 'ind_usa', 'player_weight', 'player_height']
hand_players_12_13 = players_12_13_model[hand_selected_vars]
hand_players_23_24 = players_23_24_model[hand_selected_vars]


###################################
######## Feature Evaluation #######
###################################

# big loop to compare cluster difference scores
def run_k_selection_and_record_scores(datasets, k_range=(2, 11)):
    results = []

    for dataset_name, data in datasets.items():
        print(f"Processing dataset: {dataset_name}")

        # Initialize KMeans and KElbowVisualizer
        model = KMeans(random_state=1, n_init='auto')
        visualizer = KElbowVisualizer(model, k=k_range, metric='calinski_harabasz', timings=False, locate_elbow=True)

        # Fit the visualizer to the data
        visualizer.fit(data)
        visualizer.show()
        # Record silhouette scores
        for k, score in zip(range(k_range[0], k_range[1] + 1), visualizer.k_scores_):
            results.append({'Dataset': dataset_name, 'K': k, 'CH Index': score})

    # Convert results to a DataFrame
    results_df = pd.DataFrame(results)
    return results_df


# list of datasets to compare
datasets = {
    'pfa_players_12_13': StandardScaler().fit_transform(pfa_players_12_13),
    'pfa_players_23_24': StandardScaler().fit_transform(pfa_players_23_24),
    'hand_players_12_13': StandardScaler().fit_transform(hand_players_12_13),
    'hand_players_23_24': StandardScaler().fit_transform(hand_players_23_24),
    'players_12_13_model': StandardScaler().fit_transform(players_12_13_model),
    'players_23_24_model': StandardScaler().fit_transform(players_23_24_model),
}

# execute
k_range = (2, 15)
results_df = run_k_selection_and_record_scores(datasets, k_range=k_range)
results_df['Is 12_13'] = results_df['Dataset'].str.contains("12_13")
results_df.to_csv('eval_scores.csv', index=False)
plt.close()

####################################
# Final KMeans Implementation ######
####################################

# standardize data
scaler = StandardScaler()
scaler_players_23_24 = scaler.fit_transform(pfa_players_23_24)
scaler_players_12_13 = scaler.fit_transform(pfa_players_12_13)

# run KMeans
kmeans_model_12_13 = KMeans(random_state=1, n_init='auto', n_clusters=3)
kmeans_model_23_24 = KMeans(random_state=1, n_init='auto', n_clusters=3)
kmeans_model_12_13.fit(scaler_players_12_13)
kmeans_model_23_24.fit(scaler_players_23_24)

# predict
players_12_13_edited['cluster'] = kmeans_model_12_13.predict(scaler_players_12_13)
players_12_13_edited.to_csv('player_cluster_12_13.csv', index=False)
players_23_24_edited['cluster'] = kmeans_model_23_24.predict(scaler_players_23_24)
players_23_24_edited.to_csv('player_cluster_23_24.csv', index=False)

####################################
########### PCA and graph ##########
####################################
pca = PCA(n_components=2)
pca_12_13 = pca.fit_transform(scaler_players_12_13)
pca_23_24 = pca.fit_transform(scaler_players_23_24)

pca_12_13_df = pd.DataFrame(pca_12_13, columns=['PC1', 'PC2'])
pca_23_24_df = pd.DataFrame(pca_23_24, columns=['PC1', 'PC2'])

# plot the first two principal components, include cluster labels
# 12-13
plt.figure(figsize=(8, 6))
plt.scatter(pca_12_13_df['PC1'], pca_12_13_df['PC2'], alpha=0.7, c=players_12_13_edited['cluster'], cmap='viridis')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.title('PCA of Player Clusters, 2012-13')
plt.colorbar()
plt.savefig('pca_cluster_12_13.png')
plt.show()

# 23-24
plt.figure(figsize=(8, 6))
plt.scatter(pca_23_24_df['PC1'], pca_23_24_df['PC2'], alpha=0.7, c=players_23_24_edited['cluster'], cmap='viridis')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.title('PCA of Player Clusters, 2023-24')
plt.colorbar()
plt.savefig('pca_cluster_23_24.png')
plt.show()

####################################
########### Link Clusters ##########
####################################

# take centroids and find closest (euclidean) centroid in other model
centroids_12_13 = kmeans_model_12_13.cluster_centers_
centroids_23_24 = kmeans_model_23_24.cluster_centers_

# compute distances
distances_12_13 = pairwise_distances(centroids_12_13, centroids_23_24, metric='euclidean')
distances_23_24 = pairwise_distances(centroids_23_24, centroids_12_13, metric='euclidean')

# and find closest (euclidean) centroid in other model
cluster_mapping_12_13 = np.argmin(distances_12_13, axis=1)
min_distances_12_13 = distances_12_13[np.arange(distances_12_13.shape[0]), cluster_mapping_12_13]

cluster_mapping_23_24 = np.argmin(distances_23_24, axis=1)
min_distances_23_24 = distances_23_24[np.arange(distances_23_24.shape[0]), cluster_mapping_23_24]

# store the results
cluster_df_12_13 = pd.DataFrame({'cluster_12_13': np.arange(len(cluster_mapping_12_13)),
                                 'closest_cluster_23_24': cluster_mapping_12_13,
                                 'euclidean_distance': min_distances_12_13})

cluster_df_23_24 = pd.DataFrame({'cluster_23_24': np.arange(len(cluster_mapping_23_24)),
                                 'closest_cluster_12_13': cluster_mapping_23_24,
                                 'euclidean_distance': min_distances_23_24})


####################################
####### Positional Purity ##########
####################################
# find positional mode of each cluster
def positional_purity(player_df, cluster_df, merge_column):
    position_stats = (
        player_df.groupby('cluster')['Pos_per_gm'].apply(lambda x: x.mode()[0]).reset_index(
            name='most_likely_position')
    )
    # find percentage of the mode position in each cluster
    position_percentage = (
        player_df.groupby('cluster')['Pos_per_gm']
        .apply(lambda x: (x == x.mode()[0]).mean() * 100)  # Percentage of mode position in each cluster
        .reset_index(name='position_percentage')
    )
    # merge the position stats and percentage
    cluster_position_info = pd.merge(position_stats, position_percentage, on='cluster')
    cluster_position_info = cluster_position_info.rename(columns={'cluster': merge_column})

    # merge with cluster_df to append the position and percentage data
    cluster_df = pd.merge(cluster_df, cluster_position_info, on=merge_column, how='left')
    # add in counts of players per cluster
    player_count_12_13 = pd.DataFrame(player_df['cluster'].value_counts().reset_index())
    player_count_12_13 = player_count_12_13.rename(columns={'cluster': merge_column})
    cluster_df = pd.merge(cluster_df, player_count_12_13, on=merge_column, how='left')

    return cluster_df


clusters_12_13 = positional_purity(players_12_13_edited, cluster_df_12_13, 'cluster_12_13')
clusters_12_13.to_csv('cluster_eval_12_13.csv', index=False)

clusters_23_24 = positional_purity(players_23_24_edited, cluster_df_23_24, 'cluster_23_24')
clusters_23_24.to_csv('cluster_eval_23_24.csv', index=False)
